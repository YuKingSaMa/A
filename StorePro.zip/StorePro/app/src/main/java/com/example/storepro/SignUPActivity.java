package com.example.storepro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import butterknife.BindView;
import butterknife.OnClick;

public class SignUPActivity extends AppCompatActivity {

    @BindView(R.id.edit_sign_up_name)
    TextInputEditText mName = null;
    @BindView(R.id.edit_sign_up_email)
    TextInputEditText mEmail = null;
    @BindView(R.id.edit_sign_up_phone)
    TextInputEditText mPhone = null;
    @BindView(R.id.edit_sign_up_password)
    TextInputEditText mPassword = null;
    @BindView(R.id.edit_sign_up_re_password)
    TextInputEditText mRePassword = null;

    @OnClick(R.id.btn_singup)
    void onClickSingup(){
        if (checkForm()){
            Toast.makeText(this,"注册成功",Toast.LENGTH_LONG).show();
        }
    }

    private boolean checkForm(){
        final String name = mName.getText().toString();
        final String email = mEmail.getText().toString();
        final String phone = mPhone.getText().toString();
        final String password = mPassword.getText().toString();
        final String repassword = mRePassword.getText().toString();

        boolean isPass = true;

        if (name.isEmpty()){
            mName.setError("请输入用户名");
            isPass = false;
        }else {
            mName.setError(null);
        }

        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            mEmail.setError("邮箱格式错误");
        }else {
            mEmail.setError(null);
        }

        if (phone.isEmpty() || phone.length()!=11){
            mPhone.setError("手机号码错误");
        }else {
            mPhone.setError(null);
        }

        if (password.isEmpty() || password.length()<6){
            mPassword.setError("密码位数至少为6");
            isPass = false;
        }else {
            mPassword.setError(null);
        }

        if (repassword.isEmpty()||repassword.length()<6||!(repassword.equals(password))){
            mRePassword.setError("两次密码不一致");
        }else {
            mRePassword.setError(null);
        }

        return isPass;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
    }
}
